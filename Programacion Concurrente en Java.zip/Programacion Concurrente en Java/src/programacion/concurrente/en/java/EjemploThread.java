/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programacion.concurrente.en.java;


public class EjemploThread extends Thread {
    public void run(){
         System.out.println("Hilo en ejecución: " + Thread.currentThread().getName());      
    }
    
    public static void main(String[] args) {
        EjemploThread hilo1 = new EjemploThread();
        EjemploThread hilo2 = new EjemploThread();
        hilo1.start();
        hilo2.start();
    }
}
        
